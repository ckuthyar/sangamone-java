package com.sangamone.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sangamone.entity.Pincode2;

public interface Pincode2Repo extends JpaRepository<Pincode2, Integer> {

}
